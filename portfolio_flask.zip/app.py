
from flask import Flask, render_template

app = Flask(__name__)

@app.route('/')
def home():
    return render_template(
        'index.html',
        about_text="""Passionate about AI and web development. Experienced with Generative AI, LLMs, and front-end technologies.""",
        projects=[
            "Word Sphere – AI-powered word chain game.",
            "RAG for C Programming – Code assist using RAG.",
            "Q&A Bot – Instant answers using LLMs.",
            "BMI Calculator – Web app with Flask."
        ],
        images=["https://via.placeholder.com/250x160"] * 8
    )

if __name__ == '__main__':
    app.run(debug=True)
